import React, { useState, useEffect } from "react";
import Fetchtable from "./Fetchtable";
import {
  Modal,
  Button,
  Spin,
  Tooltip,
  List,
  Select,
  message,
  Input,
  Row,
  Col,
  Drawer,
  DatePicker
} from "antd";
import { TiEyeOutline } from "react-icons/ti";
import axios from "axios";
import moment from "moment";
import { CiEdit } from "react-icons/ci";
import { AiOutlineCheckCircle, AiOutlineDelete } from "react-icons/ai";
import useAuth from "../hooks/useAuth";

const { Option } = Select;
const { TextArea } = Input;

const URL = process.env.REACT_APP_API_URL;
const Viewjob = ({ auth }) => {
  const { token, role } = useAuth();
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [selectedJob, setSelectedJob] = useState(null);
  const [filteredJobs, setFilteredJobs] = useState([]);
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(false);

  const [selectedStatus, setSelectedStatus] = useState("");
  const [isEditClicked, setIsEditClicked] = useState(false);
  const [isConfirmModalVisible, setIsConfirmModalVisible] = useState(false);
  const [jobToDelete, setJobToDelete] = useState(null);
  const [isDrawerVisible, setIsDrawerVisible] = useState(false);
  const [historyData, setHistoryData] = useState([]);

  const [editFields, setEditFields] = useState({
    position: "",
    department: "",
    jobLocation: "",
    experience: "",
    vacancies: "",
    postedBy: "",
    status: "",
    description: "",
    note: "",
    fullfilledBy: ""
  });

  const colors = {
    Active: "green",
    Hold: "#00B4D2",
    Closed: "red",
  };

  useEffect(() => {
    const fetchJobs = async () => {
      try {
        const response = await axios.get(`${URL}/viewjobs`, {
          params: { mgrRole: auth.role, fullName: auth.fullName },
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setJobs(response.data.reverse());
        setFilteredJobs(response.data.reverse());
      } catch (error) {
        console.error("Error fetching jobs:", error);
      }
    };

    fetchJobs();
  }, [auth.role, auth.fullName, token]);

  useEffect(() => {
    console.log("Filtered Jobs for Sahil Grid View: ");
    console.log(filteredJobs);

    console.log("Jobs for Sahil Grid View: ");
    console.log(jobs);

    console.log(auth);

  }, [filteredJobs, jobs]);

  const handleDateChange = (date, dateString) => {
    if (date && date.isBefore(moment(), "day")) {
      message.error("Fullfilled By date should be a future date");
      setEditFields((prevData) => ({
        ...prevData,
        fullfilledBy: "",
      }));
    } else {
      setEditFields((prevData) => ({
        ...prevData,
        fullfilledBy: dateString,

      }));
    }
  };


  const userColumns = [
    { name: "Role", selector: (row) => row.position, sortable: true },
    { name: "Department", selector: (row) => row.department, sortable: true },
    {
      name: "Location",
      selector: (row) => row.jobLocation,
      sortable: true,
      width: "150px",
    },
    {
      name: "HR Name",
      selector: (row) => row.postedBy,
      sortable: true,
      width: "150px",
    },
    {
      name: "Status",
      selector: (row) => row.status,
      sortable: true,
      width: "100px",
      cell: (row) => (
        <div
          style={{
            backgroundColor: getStatusColor(row.status),
            color: "white",
            padding: "5px 10px",
            borderRadius: "5px",
            textAlign: "center",
            alignItems: "center",
          }}
        >
          {row.status}
        </div>
      ),
    },
    {
      name: "Action",
      cell: (row) => (
        <>
          <Tooltip title="View Details" color="cyan">
            <button
              className="table-btn"
              name="View"
              onClick={() => handleRowButtonClick(row._id)}
            >
              <TiEyeOutline />
            </button>
          </Tooltip>
          {auth.role === "Admin" && (
            <Tooltip title="Delete Job" color="cyan">
              <button
                className="table-btn"
                name="delete"
                onClick={() => showConfirmModal(row._id)}
              >
                <AiOutlineDelete />
              </button>
            </Tooltip>
          )}
        </>
      ),
      ignoreRowClick: true,
      allowOverflow: true,
      button: true,
    },
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case "Active":
        return "green";
      case "Hold":
        return "#00B4D2";
      case "Closed":
        return "red";
      default:
        return "black";
    }
  };

  const handleRowButtonClick = async (jobId) => {
    setLoading(true);
    try {
      const response = await axios.get(
        `${URL}/job-posts/${jobId}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      const job = response.data;
      setSelectedJob(job);
      setEditFields({
        position: job.position,
        department: job.department,
        jobLocation: job.jobLocation,
        experience: job.experience,
        vacancies: job.vacancies,
        postedBy: job.postedBy,
        fullfilledBy: job.fullfilledBy,
        status: job.status,
        description: job.description,
        note: "", // Initialize note as an empty string
      });
      setIsModalVisible(true);
    } catch (error) {
      console.error("Error fetching job details:", error);
    } finally {
      setLoading(false);
    }
  };

  const disabledDate = (current) => {
    // Disable dates before today and after 60 days from today
    const today = moment();
    const maxDate = moment().add(240, 'days');
    return current && (current < today.startOf('day') || current > maxDate.endOf('day'));
  };

  const showConfirmModal = (jobId) => {
    setJobToDelete(jobId);
    setIsConfirmModalVisible(true);
  };

  const handleConfirmDelete = async () => {
    try {
      const response = await axios.delete(
        `${URL}/job-posts/${jobToDelete}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      if (response.status === 200) {
        const updatedJobs = jobs.filter((job) => job._id !== jobToDelete);
        setJobs(updatedJobs);
        // setFilteredJobs(updatedJobs);
        message.success("Job deleted successfully!");
      } else {
        message.error(
          "Failed to delete job. Please check server logs for details."
        );
      }
    } catch (error) {
      message.error("An error occurred while deleting the job", error);
    } finally {
      setIsConfirmModalVisible(false);
      setJobToDelete(null);
    }
  };

  const handleCancelDelete = () => {
    setIsConfirmModalVisible(false);
    setJobToDelete(null);
  };

  const handleCancel = () => {
    setIsModalVisible(false);
    setSelectedJob(null);
    setIsEditClicked(false);
    setSelectedStatus("");
  };

  const handleSaveChanges = async () => {
    setLoading(true);
    try {
      // Determine which fields have changed
      const changes = [];
      Object.keys(editFields).forEach((key) => {
        if (key !== 'note' && editFields[key] !== selectedJob[key]) {
          changes.push({ field: key, oldValue: selectedJob[key], newValue: editFields[key] });
        }
      });

      // Create history entry
      const historyEntry = {
        date: new Date(),
        updatedBy: auth.fullName,
        note: `Updated fields: ${changes.map(change => `${change.field} (from "${change.oldValue}" to "${change.newValue}")`).join(", ")}. Note: ${editFields.note}`,
      };

      const updatedJob = {
        ...editFields,
        updatedAt: new Date(),
        updatedBy: auth.fullName,
        history: [...(selectedJob.history || []), historyEntry],
      };

      // Update job in backend
      await axios.put(
        `${URL}/job-posts/${selectedJob._id}`,
        updatedJob,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      // Update job list locally
      const updatedJobs = jobs.map((job) =>
        job._id === selectedJob._id ? updatedJob : job
      );
      setJobs(updatedJobs);
      // setFilteredJobs(updatedJobs);

      setIsModalVisible(false);
      setIsEditClicked(false);
    } catch (error) {
      console.error("Error updating job details:", error);
    } finally {
      setLoading(false);
    }
  };



  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEditFields((prevFields) => ({
      ...prevFields,
      [name]: value,
    }));
  };

  const renderResumeLink = (selectedJob) => {
    if (selectedJob.jd) {
      const downloadLink = `${URL}${selectedJob.jd}`;
      return (
        <a href={downloadLink} target="_blank" rel="noopener noreferrer" style={{ color: "#00B4D2" }}>
          View JD
        </a>
      );
    } else {
      return "JD not available";
    }
  };

  const daysRemaining = selectedJob ? moment(selectedJob.fullfilledBy).diff(moment(), 'days') : 0;

  const handleHistoryClick = (job) => {
    if (job.history) {
      const sortedHistory = job.history.reverse();
      setHistoryData(sortedHistory);
    } else {
      setHistoryData([]);
    }
    setIsDrawerVisible(true);
  };

  const handleDrawerClose = () => {
    setIsDrawerVisible(false);
  };

  return (
    <div>
      {auth.role === "Hiring-Manager" ? (
        <div>
          <Fetchtable
            url={`${URL}/viewjobs?mgrRole=Hiring-Manager&fullName=${auth.fullName}`}
            columns={userColumns}
            filteredData={filteredJobs}
          />
          <Modal
            title={`This position ends in ${daysRemaining} days`}
            open={isModalVisible}
            onCancel={handleCancel}
            footer={null}
            width={800}
          >
            {loading ? (
              <Spin />
            ) : selectedJob ? (
              <>
                <div
                  style={{ justifyContent: "space-between", alignItems: "center" }}
                >
                  <h2
                    style={{
                      fontWeight: "bold",
                      marginRight: "auto",
                      fontSize: "20px",
                      color: "#00B4D2",
                    }}
                  >
                    Job Title:{" "}
                    {isEditClicked ? (
                      <Input
                        name="position"
                        value={editFields.position}
                        onChange={handleInputChange}
                      />
                    ) : (
                      selectedJob.position
                    )}
                  </h2>

                  <div style={{ display: "flex", justifyContent: "flex-end" }}>
                    <div style={{ textTransform: 'capitalize', padding: '5px' }}>
                      {renderResumeLink(selectedJob)}
                    </div>
                    <Button
                      style={{ marginRight: "10px" }}
                      onClick={() => handleHistoryClick(selectedJob)}
                    >
                      History
                    </Button>
                    <h1
                      style={{
                        fontWeight: "bold",
                        color: colors[selectedJob.status],
                        width: "100px",
                        margin: 0,
                      }}
                    >
                      {isEditClicked ? (
                        <Select
                          style={{ width: "100px" }}
                          key="status"
                          value={editFields.status}
                          onChange={(value) =>
                            setEditFields((prevFields) => ({
                              ...prevFields,
                              status: value,
                            }))
                          }
                        >
                          <Option value="Hold">Hold</Option>
                          <Option value="Active">Active</Option>
                          <Option value="Closed">Closed</Option>
                        </Select>
                      ) : (
                        selectedJob.status
                      )}
                    </h1>
                    <Tooltip title="Edit" color="cyan">
                      <button
                        className="table-btn"
                        name="edit"
                        onClick={() => setIsEditClicked(true)}
                      >
                        <CiEdit />
                      </button>
                    </Tooltip>
                    {isEditClicked && (
                      <Tooltip title="Save" color="cyan">
                        <button
                          className="table-btn"
                          name="save"
                          onClick={handleSaveChanges}
                        >
                          <AiOutlineCheckCircle />
                        </button>
                      </Tooltip>
                    )}
                  </div>
                </div>
                <Row gutter={16} style={{ marginTop: "30px" }}>
                  <Col span={24}>
                    <Row gutter={16}>
                      <Col span={8}>
                        <div>
                          <h3
                            style={{
                              fontWeight: "bold",
                              fontSize: "16px",
                              margin: "5px 0",
                              color: '#000834',
                            }}
                          >
                            Department:
                          </h3>
                          <p>
                            {isEditClicked ? (
                              <Input
                                name="department"
                                value={editFields.department}
                                onChange={handleInputChange}
                              />
                            ) : (
                              selectedJob.department
                            )}
                          </p>
                        </div>
                      </Col>
                      <Col span={8}>
                        <div>
                          <h3
                            style={{
                              fontWeight: "bold",
                              fontSize: "16px",
                              margin: "5px 0",
                              color: '#000834',
                            }}
                          >
                            Location:
                          </h3>
                          <p>
                            {isEditClicked ? (
                              <Input
                                name="jobLocation"
                                value={editFields.jobLocation}
                                onChange={handleInputChange}
                              />
                            ) : (
                              selectedJob.jobLocation
                            )}
                          </p>
                        </div>
                      </Col>
                      <Col span={8}>
                        <div>
                          <h3
                            style={{
                              fontWeight: "bold",
                              fontSize: "16px",
                              margin: "5px 0",
                              color: '#000834',
                            }}
                          >
                            Experience:
                          </h3>
                          <p>
                            {isEditClicked ? (
                              <Input
                                name="experience"
                                value={editFields.experience}
                                onChange={handleInputChange}
                              />
                            ) : (
                              selectedJob.experience
                            )}
                          </p>
                        </div>
                      </Col>
                    </Row>
                    <Row gutter={16}>
                      <Col span={8}>
                        <div>
                          <h3
                            style={{
                              fontWeight: "bold",
                              fontSize: "16px",
                              margin: "5px 0",
                              color: '#000834',
                            }}
                          >
                            Vacancies:
                          </h3>
                          <p>
                            {isEditClicked ? (
                              <Input
                                name="vacancies"
                                value={editFields.vacancies}
                                onChange={handleInputChange}
                              />
                            ) : (
                              selectedJob.vacancies
                            )}
                          </p>
                        </div>
                      </Col>
                      <Col span={8}>
                        <div>
                          <h3
                            style={{
                              fontWeight: "bold",
                              fontSize: "16px",
                              margin: "5px 0",
                              color: '#000834',
                            }}
                          >
                            Posted By:
                          </h3>
                          <p>
                            {isEditClicked ? (
                              <Input
                                name="postedBy"
                                value={editFields.postedBy}
                                onChange={handleInputChange}
                              />
                            ) : (
                              selectedJob.postedBy
                            )}
                          </p>
                        </div>
                      </Col>
                      <Col span={8}>
                        <div>
                          <h3
                            style={{
                              fontWeight: "bold",
                              fontSize: "16px",
                              margin: "5px 0",
                              color: '#000834',
                            }}
                          >
                            FullfilledBy:
                          </h3>
                          <p>
                            {isEditClicked ? (
                              <DatePicker
                                name="fullfilledBy"
                                value={
                                  editFields.fullfilledBy ? moment(editFields.fullfilledBy) : null
                                }
                                onChange={handleDateChange}
                                format="YYYY-MM-DD"
                                disabledDate={disabledDate}
                              />
                            ) : (
                              selectedJob.fullfilledBy ? moment(selectedJob.fullfilledBy).format('DD-MM-YYYY') : 'N/A'
                            )}
                          </p>
                        </div>
                      </Col>
                    </Row>
                    <Row gutter={16}>
                      <Col span={8}>
                        <div>
                          <h3
                            style={{
                              fontWeight: "bold",
                              fontSize: "16px",
                              margin: "5px 0",
                              color: '#000834',
                            }}
                          >
                            Primary Skills:
                          </h3>
                          <p>
                            {isEditClicked ? (
                              <Input
                                name="primarySkills"
                                value={editFields.primarySkills}
                                onChange={handleInputChange}
                              />
                            ) : (
                              selectedJob.primarySkills
                            )}
                          </p>
                        </div>
                      </Col>
                      <Col span={8}>
                        <div>
                          <h3
                            style={{
                              fontWeight: "bold",
                              fontSize: "16px",
                              margin: "5px 0",
                              color: '#000834',
                            }}
                          >
                            Secondary Skills:
                          </h3>
                          <p>
                            {isEditClicked ? (
                              <Input
                                name="secondarySkills"
                                value={editFields.secondarySkills}
                                onChange={handleInputChange}
                              />
                            ) : (
                              selectedJob.secondarySkills
                            )}
                          </p>
                        </div>
                      </Col>
                    </Row>

                    <Row gutter={16}>
                      <Col span={24}>
                        <div>
                          <h3
                            style={{
                              fontWeight: "bold",
                              fontSize: "16px",
                              margin: "5px 0",
                              color: '#000834',
                            }}
                          >
                            Description:
                          </h3>
                          <p>
                            {isEditClicked ? (
                              <TextArea
                                name="description"
                                value={editFields.description}
                                onChange={handleInputChange}
                              />
                            ) : (
                              selectedJob.description
                            )}
                          </p>
                        </div>
                      </Col>
                    </Row>
                    {isEditClicked && (
                      <Row gutter={16}>
                        <Col span={24}>
                          <div>
                            <h3
                              style={{
                                fontWeight: "bold",
                                fontSize: "16px",
                                margin: "5px 0",
                                color: "red",
                              }}
                            >
                              Reason For This Update:
                            </h3>
                            <TextArea
                              name="note"
                              value={editFields.note}
                              placeHolder="Please mention reason for update & what is updated"
                              onChange={handleInputChange}
                            />
                          </div>
                        </Col>
                      </Row>
                    )}
                  </Col>
                </Row>
              </>
            ) : (
              <p>No job selected</p>
            )}
          </Modal>
          <Modal
            title="Confirm Delete"
            open={isConfirmModalVisible}
            onOk={handleConfirmDelete}
            onCancel={handleCancelDelete}
          >
            <p>Are you sure you want to delete this job?</p>
          </Modal>
          <Drawer
            title="History Data"
            placement="left"
            closable={true}
            onClose={handleDrawerClose}
            open={isDrawerVisible}
            width={400}
          >
            {historyData.length > 0 ? (
              <List
                dataSource={historyData}
                renderItem={(item, index) => (
                  <List.Item key={index}>
                    <List.Item.Meta
                      title={`Date: ${moment(item.date).format(
                        "DD MMMM YYYY, HH:mm"
                      )}`}
                      description={
                        <>
                          <p>Comments: {item.note}</p>
                          <p>Updated By: {item.updatedBy}</p>
                        </>
                      }
                    />
                  </List.Item>
                )}
              />
            ) : (
              <p>No history available</p>
            )}
          </Drawer>
        </div>
      ) : (
        <div>
          <Fetchtable
            url={`${URL}/viewjobs`}
            columns={userColumns}
            filteredData={filteredJobs}
          />
          <Modal
            title={`This position ends in ${daysRemaining} days`}
            open={isModalVisible}
            onCancel={handleCancel}
            footer={null}
            width={800}
          >
            {loading ? (
              <Spin />
            ) : selectedJob ? (
              <>
                <div
                  style={{ justifyContent: "space-between", alignItems: "center" }}
                >
                  <h2
                    style={{
                      fontWeight: "bold",
                      marginRight: "auto",
                      fontSize: "20px",
                      color: "#00B4D2",
                    }}
                  >
                    Job Title:{" "}
                    {isEditClicked ? (
                      <Input
                        name="position"
                        value={editFields.position}
                        onChange={handleInputChange}
                      />
                    ) : (
                      selectedJob.position
                    )}
                  </h2>

                  <div style={{ display: "flex", justifyContent: "flex-end" }}>
                    <div style={{ textTransform: 'capitalize', padding: '5px' }}>
                      {renderResumeLink(selectedJob)}
                    </div>
                    <Button
                      style={{ marginRight: "10px" }}
                      onClick={() => handleHistoryClick(selectedJob)}
                    >
                      History
                    </Button>
                    <h1
                      style={{
                        fontWeight: "bold",
                        color: colors[selectedJob.status],
                        width: "100px",
                        margin: 0,
                      }}
                    >
                      {isEditClicked ? (
                        <Select
                          style={{ width: "100px" }}
                          key="status"
                          value={editFields.status}
                          onChange={(value) =>
                            setEditFields((prevFields) => ({
                              ...prevFields,
                              status: value,
                            }))
                          }
                        >
                          <Option value="Hold">Hold</Option>
                          <Option value="Active">Active</Option>
                          <Option value="Closed">Closed</Option>
                        </Select>
                      ) : (
                        selectedJob.status
                      )}
                    </h1>
                    <Tooltip title="Edit" color="cyan">
                      <button
                        className="table-btn"
                        name="edit"
                        onClick={() => setIsEditClicked(true)}
                      >
                        <CiEdit />
                      </button>
                    </Tooltip>
                    {isEditClicked && (
                      <Tooltip title="Save" color="cyan">
                        <button
                          className="table-btn"
                          name="save"
                          onClick={handleSaveChanges}
                        >
                          <AiOutlineCheckCircle />
                        </button>
                      </Tooltip>
                    )}
                  </div>
                </div>
                <Row gutter={16} style={{ marginTop: "30px" }}>
                  <Col span={24}>
                    <Row gutter={16}>
                      <Col span={8}>
                        <div>
                          <h3
                            style={{
                              fontWeight: "bold",
                              fontSize: "16px",
                              margin: "5px 0",
                              color: '#000834',
                            }}
                          >
                            Department:
                          </h3>
                          <p>
                            {isEditClicked ? (
                              <Input
                                name="department"
                                value={editFields.department}
                                onChange={handleInputChange}
                              />
                            ) : (
                              selectedJob.department
                            )}
                          </p>
                        </div>
                      </Col>
                      <Col span={8}>
                        <div>
                          <h3
                            style={{
                              fontWeight: "bold",
                              fontSize: "16px",
                              margin: "5px 0",
                              color: '#000834',
                            }}
                          >
                            Location:
                          </h3>
                          <p>
                            {isEditClicked ? (
                              <Input
                                name="jobLocation"
                                value={editFields.jobLocation}
                                onChange={handleInputChange}
                              />
                            ) : (
                              selectedJob.jobLocation
                            )}
                          </p>
                        </div>
                      </Col>
                      <Col span={8}>
                        <div>
                          <h3
                            style={{
                              fontWeight: "bold",
                              fontSize: "16px",
                              margin: "5px 0",
                              color: '#000834',
                            }}
                          >
                            Experience:
                          </h3>
                          <p>
                            {isEditClicked ? (
                              <Input
                                name="experience"
                                value={editFields.experience}
                                onChange={handleInputChange}
                              />
                            ) : (
                              selectedJob.experience
                            )}
                          </p>
                        </div>
                      </Col>
                    </Row>
                    <Row gutter={16}>
                      <Col span={8}>
                        <div>
                          <h3
                            style={{
                              fontWeight: "bold",
                              fontSize: "16px",
                              margin: "5px 0",
                              color: '#000834',
                            }}
                          >
                            Vacancies:
                          </h3>
                          <p>
                            {isEditClicked ? (
                              <Input
                                name="vacancies"
                                value={editFields.vacancies}
                                onChange={handleInputChange}
                              />
                            ) : (
                              selectedJob.vacancies
                            )}
                          </p>
                        </div>
                      </Col>
                      <Col span={8}>
                        <div>
                          <h3
                            style={{
                              fontWeight: "bold",
                              fontSize: "16px",
                              margin: "5px 0",
                              color: '#000834',
                            }}
                          >
                            Posted By:
                          </h3>
                          <p>
                            {isEditClicked ? (
                              <Input
                                name="postedBy"
                                value={editFields.postedBy}
                                onChange={handleInputChange}
                              />
                            ) : (
                              selectedJob.postedBy
                            )}
                          </p>
                        </div>
                      </Col>
                      <Col span={8}>
                        <div>
                          <h3
                            style={{
                              fontWeight: "bold",
                              fontSize: "16px",
                              margin: "5px 0",
                              color: '#000834',
                            }}
                          >
                            FullfilledBy:
                          </h3>
                          <p>
                            {isEditClicked ? (
                              <DatePicker
                                name="fullfilledBy"
                                value={
                                  editFields.fullfilledBy ? moment(editFields.fullfilledBy) : null
                                }
                                onChange={handleDateChange}
                                format="YYYY-MM-DD"
                                disabledDate={disabledDate}
                              />
                            ) : (
                              selectedJob.fullfilledBy ? moment(selectedJob.fullfilledBy).format('DD-MM-YYYY') : 'N/A'
                            )}
                          </p>
                        </div>
                      </Col>
                    </Row>
                    <Row gutter={16}>
                      <Col span={8}>
                        <div>
                          <h3
                            style={{
                              fontWeight: "bold",
                              fontSize: "16px",
                              margin: "5px 0",
                              color: '#000834',
                            }}
                          >
                            Primary Skills:
                          </h3>
                          <p>
                            {isEditClicked ? (
                              <Input
                                name="primarySkills"
                                value={editFields.primarySkills}
                                onChange={handleInputChange}
                              />
                            ) : (
                              selectedJob.primarySkills
                            )}
                          </p>
                        </div>
                      </Col>
                      <Col span={8}>
                        <div>
                          <h3
                            style={{
                              fontWeight: "bold",
                              fontSize: "16px",
                              margin: "5px 0",
                              color: '#000834',
                            }}
                          >
                            Secondary Skills:
                          </h3>
                          <p>
                            {isEditClicked ? (
                              <Input
                                name="secondarySkills"
                                value={editFields.secondarySkills}
                                onChange={handleInputChange}
                              />
                            ) : (
                              selectedJob.secondarySkills
                            )}
                          </p>
                        </div>
                      </Col>
                    </Row>

                    <Row gutter={16}>
                      <Col span={24}>
                        <div>
                          <h3
                            style={{
                              fontWeight: "bold",
                              fontSize: "16px",
                              margin: "5px 0",
                              color: '#000834',
                            }}
                          >
                            Description:
                          </h3>
                          <p>
                            {isEditClicked ? (
                              <TextArea
                                name="description"
                                value={editFields.description}
                                onChange={handleInputChange}
                              />
                            ) : (
                              selectedJob.description
                            )}
                          </p>
                        </div>
                      </Col>
                    </Row>
                    {isEditClicked && (
                      <Row gutter={16}>
                        <Col span={24}>
                          <div>
                            <h3
                              style={{
                                fontWeight: "bold",
                                fontSize: "16px",
                                margin: "5px 0",
                                color: "red",
                              }}
                            >
                              Reason For This Update:
                            </h3>
                            <TextArea
                              name="note"
                              value={editFields.note}
                              placeHolder="Please mention reason for update & what is updated"
                              onChange={handleInputChange}
                            />
                          </div>
                        </Col>
                      </Row>
                    )}
                  </Col>
                </Row>
              </>
            ) : (
              <p>No job selected</p>
            )}
          </Modal>
          <Modal
            title="Confirm Delete"
            open={isConfirmModalVisible}
            onOk={handleConfirmDelete}
            onCancel={handleCancelDelete}
          >
            <p>Are you sure you want to delete this job?</p>
          </Modal>
          <Drawer
            title="History Data"
            placement="left"
            closable={true}
            onClose={handleDrawerClose}
            open={isDrawerVisible}
            width={400}
          >
            {historyData.length > 0 ? (
              <List
                dataSource={historyData}
                renderItem={(item, index) => (
                  <List.Item key={index}>
                    <List.Item.Meta
                      title={`Date: ${moment(item.date).format(
                        "DD MMMM YYYY, HH:mm"
                      )}`}
                      description={
                        <>
                          <p>Comments: {item.note}</p>
                          <p>Updated By: {item.updatedBy}</p>
                        </>
                      }
                    />
                  </List.Item>
                )}
              />
            ) : (
              <p>No history available</p>
            )}
          </Drawer>
        </div>
      )}
    </div>
  );
};

export default Viewjob;
